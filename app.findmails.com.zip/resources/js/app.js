import './bootstrap';
import { Datepicker, Ripple, Input, initTE } from "tw-elements";
initTE({ Datepicker, Ripple, Input });