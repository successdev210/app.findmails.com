@extends('layouts.layout')

@section('content')
<h1>This is Home Page</h1>
@endsection