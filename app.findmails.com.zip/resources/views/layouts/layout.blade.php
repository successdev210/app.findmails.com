<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Find Mails</title>
    <link rel="stylesheet" href="{{ url('/css/style.css') }}">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    @vite(['resources/css/app.css', 'resources/js/app.js'])

</head>

<body class="">
    @include('layouts.header')
    <div class="main__container">
        @yield('content')
    </div>
    @include('layouts.footer')
    <script src="{{url('/js/jquery3.6.4.js')}}"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.6.4.js"></script> -->
    <script src="{{url('/js/circle-progress.min.js')}}"></script>
    <script src="{{url('/js/script.js')}}"></script>
</body>

</html>