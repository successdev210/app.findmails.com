<?php $__env->startSection('content'); ?>
<h1>This is Home Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\email finder\email-finder_laravel_10x\resources\views/welcome.blade.php ENDPATH**/ ?>