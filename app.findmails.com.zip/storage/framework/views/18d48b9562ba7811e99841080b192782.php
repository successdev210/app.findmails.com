<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Find Mails</title>
    <link rel="stylesheet" href="<?php echo e(url('/css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body class="">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main__container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(url('/js/jquery3.6.4.js')); ?>"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.6.4.js"></script> -->
    <script src="<?php echo e(url('/js/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(url('/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH E:\Project\Laravel\email finder\email-finder_laravel_10x\resources\views/layouts/layout.blade.php ENDPATH**/ ?>